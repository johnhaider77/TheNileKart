import React from 'react';
import OrdersManagement from '../components/OrdersManagement';

const OrdersQueue: React.FC = () => {
  return <OrdersManagement />;
};

export default OrdersQueue;